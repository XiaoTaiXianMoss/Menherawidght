# 七濑胡桃 Android 桌面小组件

七濑胡桃（Menhera-chan / Nanami）安卓桌面小组件，透明背景，内置 9 张表情。

## 功能

- **胡桃+时间**：顶部白色数字时间（HH:mm，每分钟刷新），下方胡桃表情
- **胡桃纯图**：仅胡桃表情，无时间
- 点击图片切换下一张表情（共 9 张）
- 透明背景，自动透出桌面壁纸
- 默认 2×2 尺寸，支持自由拉伸缩放

## 直接安装

下载 `releases/menhera-widget-v5.1.apk`，手机允许"未知来源应用"后安装。
安装后长按桌面 → 小组件 → 选择「胡桃+时间」或「胡桃纯图」。

## 自行编译

Android Studio 打开本目录，Gradle 同步后 Run 即可。

- minSdk 21（Android 5.0+）
- targetSdk 34
- 包名 `com.menhera.widget`

## 项目结构

```
menhera-widget/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/menhera/widget/
│       │   ├── MenheraBaseWidgetProvider.java   # 公共逻辑
│       │   ├── MenheraTimeWidgetProvider.java   # 带时间
│       │   └── MenheraPlainWidgetProvider.java    # 纯图
│       └── res/
│           ├── layout/widget_menhera_time.xml    # 时间+图布局
│           ├── layout/widget_menhera_plain.xml   # 纯图布局
│           ├── xml/menhera_time_widget_info.xml
│           ├── xml/menhera_plain_widget_info.xml
│           ├── values/strings.xml, themes.xml
│           ├── drawable/express_01.png ~ express_09.png
│           └── mipmap-hdpi/ic_launcher.png
├── releases/menhera-widget-v5.1.apk
├── build.gradle, settings.gradle, gradle.properties
└── README.md, LICENSE
```

## 素材版权

角色形象「七濑胡桃 / Menhera-chan」归原作者所有，本项目仅作爱好者同人非盈利使用。

## License

MIT
