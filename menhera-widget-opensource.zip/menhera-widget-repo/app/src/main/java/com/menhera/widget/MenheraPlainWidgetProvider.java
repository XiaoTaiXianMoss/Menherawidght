package com.menhera.widget;

/** 纯图胡桃小组件（无时间） */
public class MenheraPlainWidgetProvider extends MenheraBaseWidgetProvider {
    @Override
    protected int getLayoutId() { return R.layout.widget_menhera_plain; }
    @Override
    protected boolean showTime() { return false; }
}
