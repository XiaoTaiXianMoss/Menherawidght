package com.menhera.widget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 胡桃小组件公共逻辑：表情图 + 点击切换 + 可选时间
 */
public abstract class MenheraBaseWidgetProvider extends AppWidgetProvider {

    public static final String ACTION_NEXT = "com.menhera.widget.NEXT";
    public static final String ACTION_TICK = "com.menhera.widget.TICK";
    private static final String PREFS = "MenheraWidgetPrefs";

    static final int[] EXPRESSIONS = new int[]{
            R.drawable.express_01, R.drawable.express_02, R.drawable.express_03,
            R.drawable.express_04, R.drawable.express_05, R.drawable.express_06,
            R.drawable.express_07, R.drawable.express_08, R.drawable.express_09
    };

    /** 子类指定布局资源 id */
    protected abstract int getLayoutId();

    /** 子类指定是否显示时间 */
    protected abstract boolean showTime();

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        startAlarm(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        // 不在这里 stopAlarm，因为另一个 widget 可能还在
    }

    private void startAlarm(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, MenheraTimeWidgetProvider.class);
        i.setAction(ACTION_TICK);
        PendingIntent pi = PendingIntent.getBroadcast(context, 0, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.setRepeating(AlarmManager.RTC, System.currentTimeMillis(), 60 * 1000L, pi);
    }

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) {
            render(context, manager, id);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        AppWidgetManager am = AppWidgetManager.getInstance(context);

        if (ACTION_TICK.equals(intent.getAction())) {
            // 时间组件刷新时间
            int[] timeIds = am.getAppWidgetIds(new ComponentName(context, MenheraTimeWidgetProvider.class));
            for (int id : timeIds) render(context, am, id);
        } else if (ACTION_NEXT.equals(intent.getAction())) {
            int id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,
                    AppWidgetManager.INVALID_APPWIDGET_ID);
            advance(context, id);
            if (id != AppWidgetManager.INVALID_APPWIDGET_ID) render(context, am, id);
        }
    }

    private void advance(Context context, int widgetId) {
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int idx = prefs.getInt(keyFor(widgetId), 0);
        idx = (idx + 1) % EXPRESSIONS.length;
        prefs.edit().putInt(keyFor(widgetId), idx).apply();
    }

    private String keyFor(int widgetId) {
        return "idx_" + getClass().getSimpleName() + "_" + widgetId;
    }

    private void render(Context context, AppWidgetManager manager, int widgetId) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int idx = prefs.getInt(keyFor(widgetId), 0);

        RemoteViews views = new RemoteViews(context.getPackageName(), getLayoutId());
        views.setImageViewResource(R.id.widget_image, EXPRESSIONS[idx]);

        if (showTime()) {
            String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
            views.setTextViewText(R.id.tv_time, time);
        }

        Intent click = new Intent(context, getClass());
        click.setAction(ACTION_NEXT);
        click.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        PendingIntent pi = PendingIntent.getBroadcast(
                context, widgetId, click,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_image, pi);

        manager.updateAppWidget(widgetId, views);
    }
}
