package com.menhera.widget;

/** 带时间的胡桃小组件 */
public class MenheraTimeWidgetProvider extends MenheraBaseWidgetProvider {
    @Override
    protected int getLayoutId() { return R.layout.widget_menhera_time; }
    @Override
    protected boolean showTime() { return true; }
}
